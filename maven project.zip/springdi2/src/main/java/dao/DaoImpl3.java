
package dao;

import org.springframework.context.annotation.Profile;
import org.springframework.stereotype.Component;

@Component("dao3")
@Profile("prod")
public class DaoImpl3 implements IDao {

	@Override
	public double getValue() {
		return 500.0;
	}

}
