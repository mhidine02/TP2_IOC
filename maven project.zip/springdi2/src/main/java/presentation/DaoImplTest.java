
package presentation;

import static org.junit.jupiter.api.Assertions.assertEquals;
import org.junit.jupiter.api.Test;
import dao.DaoImpl;

	public class DaoImplTest {
	
		@Test
		public void testGetValue() {
			DaoImpl dao = new DaoImpl();
			double value = dao.getValue();
			assertEquals(100.0, value);
    }

}
