
package presentation;

import static org.junit.jupiter.api.Assertions.assertEquals;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import metier.MetierImpl;
import dao.DaoImpl;
	public class MetierImplTest {
		
		private MetierImpl metier;

	    @BeforeEach
	    public void setup() {
	        metier = new MetierImpl();
	        metier.setDao(new DaoImpl());  
	    }

	    @Test
	    public void testCalcul() {
	        double result = metier.calcul();
	        assertEquals(200.0, result);
	    }

 }
